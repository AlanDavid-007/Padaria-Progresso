<body style="background-image: linear-gradient(to right top, #c9004f, #e8413f, #fa712b, #ffa00d, #fbcf00);">
    <a href="../index.php">
        <button class="btn btn-header btn-lg">Voltar</button>
    </a>
<section class="formulario d-flex justify-content-center" >
    <form method="post" class="form-send" enctype="multipart/form-data">
        <div class="form-group">
            <label>Nome</label>
            <input type="text" required class="form-control " name="nome" value="<?php echo isset($obCategoria->nome) ? $obCategoria->nome : ''; ?>">
        </div>
        <!-- <div class="form-group">
            <label for="formFile">Imagem</label>
            <input class="form-control" type="file" name="arquivo" accept="image/*">
        </div> -->
        <div class="form-group">
            <label>Link para Produtos</label>
            <input type="text" required class="form-control " name="link" value="<?php echo isset($obCategoria->link) ? $obCategoria->link : ''; ?>">
        </div>
        <div class="form-group">
            <button type="submit" name="formbutton" class="btn btn-header btn-lg">Enviar</button>
        </div>
    </form>
</section>
<div class="alert alert-info mt-3 ml-5 mr-5">Nota:<br>Observação sobre campo link, Nele Coloque:
"/Admin/produtos/categorias.php?busca=nomedacategoria" <br> Obs: Onde está "nomedacategoria"<br> 
coloque o nome que desejar colocar para categoria <br> Exemplo: /Admin/produtos/categorias.php?busca=Bolos
</div>
</body>
