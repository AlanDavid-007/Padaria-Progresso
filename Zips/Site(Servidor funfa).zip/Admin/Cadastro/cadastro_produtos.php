<?php
require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../App/Produto.php';
use \App\Produto;
use \App\Categoria;
$obProdutos = new Produto;
$obCategorias = new Categoria;
$listaCategoria = $obCategorias::getCategorias();
   // echo "<pre>"; print_r($obPedidos); echo "</pre>"; exit;
if (isset($_POST['nome'], $_POST['descricao'], $_POST['quantidade'], $_POST['tipo'], $_POST['link'], $_POST['preco']
)) {
    $obProdutos->nome = $_POST['nome'];
    $obProdutos->descricao = $_POST['descricao'];
    $obProdutos->quantidade = $_POST['quantidade'];
    $obProdutos->tipo = $_POST['tipo'];
    // $obProdutos->imagem = $_FILES['imagem'];
    $obProdutos->link = $_POST['link'];
    $obProdutos->preco = $_POST['preco'];
    $obProdutos->cadastrar();
    //  echo "<pre>"; print_r($obProdutos); echo "</pre>"; exit; 

    header('location: /../Admin/produtos/categorias.php?status=success');
    exit;
}
require __DIR__ . '/../Includes/header_pasta.php';
require __DIR__ . '/../Includes/formulario_produtos.php';
require __DIR__ . '/../Includes/footer_pasta.php';
?>


